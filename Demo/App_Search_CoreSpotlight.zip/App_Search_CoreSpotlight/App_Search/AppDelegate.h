//
//  AppDelegate.h
//  App_Search
//
//  Created by vedon on 6/25/15.
//  Copyright © 2015 vedon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

