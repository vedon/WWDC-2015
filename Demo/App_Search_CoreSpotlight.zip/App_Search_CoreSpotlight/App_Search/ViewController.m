//
//  ViewController.m
//  App_Search
//
//  Created by vedon on 6/25/15.
//  Copyright © 2015 vedon. All rights reserved.
//

#import "ViewController.h"
#import <CoreSpotlight/CoreSpotlight.h>
#import <MobileCoreServices/MobileCoreServices.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CSSearchableItemAttributeSet* attributeSet = [[CSSearchableItemAttributeSet alloc] initWithItemContentType:(NSString *)kUTTypeImage];
    attributeSet.title = @"CoreSpotlight is awesome";
    attributeSet.contentDescription = @"wow ,you found me - CoreSpotlight";

    //添加图片
    UIImage *image = [UIImage imageNamed:@"test.png"];
    NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation(image)];
    attributeSet.thumbnailData = imageData;
    
    CSSearchableItem *item;
    item = [[CSSearchableItem alloc] initWithUniqueIdentifier:@"123456" domainIdentifier:@"domain1" attributeSet:attributeSet];
    [[CSSearchableIndex defaultSearchableIndex] indexSearchableItems:@[item] completionHandler: ^(NSError * __nullable error) {
        NSLog(@"gotcha");
    }];
    
    
    NSUserActivity *userActivity = [[NSUserActivity alloc]initWithActivityType:@"com.mycompany.activity-type"];
    userActivity.title = @"Hello world from in app search";
    userActivity.keywords = [NSSet setWithArray:@[@"NSUserActivity", @"Hello"]];
    userActivity.userInfo = @{@"id":@"com.example.state"};
    
    userActivity.eligibleForSearch = YES;
    userActivity.eligibleForPublicIndexing = YES;
    [userActivity becomeCurrent];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
